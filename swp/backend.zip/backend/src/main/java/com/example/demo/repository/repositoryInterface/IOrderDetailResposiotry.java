package com.example.demo.repository.repositoryInterface;

import com.example.demo.entity.OrderDetail;

public interface IOrderDetailResposiotry {
    public int saveOrderDetail(OrderDetail orderDetail);
}
