package com.example.demo.entity;


import lombok.*;

@AllArgsConstructor
@NoArgsConstructor
@Getter
@Setter
@ToString
public class OrderTransaction {
    private int id;
    private String value;
}
