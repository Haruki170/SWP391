package com.example.demo.repository.repositoryInterface;

public interface IPaymentRespository {

}
