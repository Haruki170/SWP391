package com.example.socket.dto;

public class CustomerConversationDto {

}
